-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: sistemagestionflotillas
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `h1_vehiculosactivos`
--

DROP TABLE IF EXISTS `h1_vehiculosactivos`;
/*!50001 DROP VIEW IF EXISTS `h1_vehiculosactivos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `h1_vehiculosactivos` AS SELECT 
 1 AS `vehiculoId`,
 1 AS `flotillaId`,
 1 AS `tipo`,
 1 AS `modelo`,
 1 AS `marca`,
 1 AS `anio`,
 1 AS `estado`,
 1 AS `fechaVerificacion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `h4_distancia`
--

DROP TABLE IF EXISTS `h4_distancia`;
/*!50001 DROP VIEW IF EXISTS `h4_distancia`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `h4_distancia` AS SELECT 
 1 AS `rutaId`,
 1 AS `vehiculoId`,
 1 AS `conductorId`,
 1 AS `horaInicio`,
 1 AS `horaFin`,
 1 AS `distancia`,
 1 AS `ubicacionInicio`,
 1 AS `ubicacionFin`,
 1 AS `estado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `h5_costomantenimiento`
--

DROP TABLE IF EXISTS `h5_costomantenimiento`;
/*!50001 DROP VIEW IF EXISTS `h5_costomantenimiento`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `h5_costomantenimiento` AS SELECT 
 1 AS `mantenimientoId`,
 1 AS `vehiculoId`,
 1 AS `fechaServicio`,
 1 AS `tipoServicio`,
 1 AS `descripcion`,
 1 AS `costo`,
 1 AS `estado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `h2_documentosvencidos`
--

DROP TABLE IF EXISTS `h2_documentosvencidos`;
/*!50001 DROP VIEW IF EXISTS `h2_documentosvencidos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `h2_documentosvencidos` AS SELECT 
 1 AS `documentoId`,
 1 AS `vehiculoId`,
 1 AS `tipo`,
 1 AS `fechaVencimiento`,
 1 AS `estado`,
 1 AS `rutaArchivo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v2`
--

DROP TABLE IF EXISTS `v2`;
/*!50001 DROP VIEW IF EXISTS `v2`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v2` AS SELECT 
 1 AS `mantenimientoId`,
 1 AS `vehiculoId`,
 1 AS `modelo`,
 1 AS `tipoServicio`,
 1 AS `Estado del mantenimiento`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `h3_vehiculosmantenimiento`
--

DROP TABLE IF EXISTS `h3_vehiculosmantenimiento`;
/*!50001 DROP VIEW IF EXISTS `h3_vehiculosmantenimiento`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `h3_vehiculosmantenimiento` AS SELECT 
 1 AS `vehiculoId`,
 1 AS `flotillaId`,
 1 AS `tipo`,
 1 AS `modelo`,
 1 AS `marca`,
 1 AS `anio`,
 1 AS `estado`,
 1 AS `fechaVerificacion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v4`
--

DROP TABLE IF EXISTS `v4`;
/*!50001 DROP VIEW IF EXISTS `v4`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v4` AS SELECT 
 1 AS `conductorId`,
 1 AS `nombre`,
 1 AS `vehiculoId`,
 1 AS `fechaTransaccion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v5`
--

DROP TABLE IF EXISTS `v5`;
/*!50001 DROP VIEW IF EXISTS `v5`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v5` AS SELECT 
 1 AS `vehiculoId`,
 1 AS `modelo`,
 1 AS `marca`,
 1 AS `tipo`,
 1 AS `fechavencimiento`,
 1 AS `estado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v3`
--

DROP TABLE IF EXISTS `v3`;
/*!50001 DROP VIEW IF EXISTS `v3`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v3` AS SELECT 
 1 AS `flotillaId`,
 1 AS `nombreEmpresa`,
 1 AS `vehiculoId`,
 1 AS `tipo`,
 1 AS `modelo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v1`
--

DROP TABLE IF EXISTS `v1`;
/*!50001 DROP VIEW IF EXISTS `v1`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v1` AS SELECT 
 1 AS `conductorId`,
 1 AS `nombre`,
 1 AS `estado`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `h1_vehiculosactivos`
--

/*!50001 DROP VIEW IF EXISTS `h1_vehiculosactivos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `h1_vehiculosactivos` AS select `vehiculo`.`vehiculoId` AS `vehiculoId`,`vehiculo`.`flotillaId` AS `flotillaId`,`vehiculo`.`tipo` AS `tipo`,`vehiculo`.`modelo` AS `modelo`,`vehiculo`.`marca` AS `marca`,`vehiculo`.`anio` AS `anio`,`vehiculo`.`estado` AS `estado`,`vehiculo`.`fechaVerificacion` AS `fechaVerificacion` from `vehiculo` where (`vehiculo`.`estado` = 'Activo') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `h4_distancia`
--

/*!50001 DROP VIEW IF EXISTS `h4_distancia`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `h4_distancia` AS select `ruta`.`rutaId` AS `rutaId`,`ruta`.`vehiculoId` AS `vehiculoId`,`ruta`.`conductorId` AS `conductorId`,`ruta`.`horaInicio` AS `horaInicio`,`ruta`.`horaFin` AS `horaFin`,`ruta`.`distancia` AS `distancia`,`ruta`.`ubicacionInicio` AS `ubicacionInicio`,`ruta`.`ubicacionFin` AS `ubicacionFin`,`ruta`.`estado` AS `estado` from `ruta` where (`ruta`.`distancia` <= 500) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `h5_costomantenimiento`
--

/*!50001 DROP VIEW IF EXISTS `h5_costomantenimiento`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `h5_costomantenimiento` AS select `mantenimiento`.`mantenimientoId` AS `mantenimientoId`,`mantenimiento`.`vehiculoId` AS `vehiculoId`,`mantenimiento`.`fechaServicio` AS `fechaServicio`,`mantenimiento`.`tipoServicio` AS `tipoServicio`,`mantenimiento`.`descripcion` AS `descripcion`,`mantenimiento`.`costo` AS `costo`,`mantenimiento`.`estado` AS `estado` from `mantenimiento` where (`mantenimiento`.`costo` >= 2000) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `h2_documentosvencidos`
--

/*!50001 DROP VIEW IF EXISTS `h2_documentosvencidos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `h2_documentosvencidos` AS select `documento`.`documentoId` AS `documentoId`,`documento`.`vehiculoId` AS `vehiculoId`,`documento`.`tipo` AS `tipo`,`documento`.`fechaVencimiento` AS `fechaVencimiento`,`documento`.`estado` AS `estado`,`documento`.`rutaArchivo` AS `rutaArchivo` from `documento` where (`documento`.`estado` = 'Vencido') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v2`
--

/*!50001 DROP VIEW IF EXISTS `v2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v2` AS select `mantenimiento`.`mantenimientoId` AS `mantenimientoId`,`mantenimiento`.`vehiculoId` AS `vehiculoId`,`vehiculo`.`modelo` AS `modelo`,`mantenimiento`.`tipoServicio` AS `tipoServicio`,`mantenimiento`.`estado` AS `Estado del mantenimiento` from (`mantenimiento` join `vehiculo`) where (`mantenimiento`.`vehiculoId` = `vehiculo`.`vehiculoId`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `h3_vehiculosmantenimiento`
--

/*!50001 DROP VIEW IF EXISTS `h3_vehiculosmantenimiento`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `h3_vehiculosmantenimiento` AS select `vehiculo`.`vehiculoId` AS `vehiculoId`,`vehiculo`.`flotillaId` AS `flotillaId`,`vehiculo`.`tipo` AS `tipo`,`vehiculo`.`modelo` AS `modelo`,`vehiculo`.`marca` AS `marca`,`vehiculo`.`anio` AS `anio`,`vehiculo`.`estado` AS `estado`,`vehiculo`.`fechaVerificacion` AS `fechaVerificacion` from `vehiculo` where (`vehiculo`.`estado` = 'Mantenimiento') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v4`
--

/*!50001 DROP VIEW IF EXISTS `v4`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v4` AS select `conductor`.`conductorId` AS `conductorId`,`conductor`.`nombre` AS `nombre`,`transaccioncombustible`.`vehiculoId` AS `vehiculoId`,`transaccioncombustible`.`fechaTransaccion` AS `fechaTransaccion` from (`conductor` join `transaccioncombustible`) where (`conductor`.`conductorId` = `transaccioncombustible`.`conductorId`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v5`
--

/*!50001 DROP VIEW IF EXISTS `v5`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v5` AS select `vehiculo`.`vehiculoId` AS `vehiculoId`,`vehiculo`.`modelo` AS `modelo`,`vehiculo`.`marca` AS `marca`,`documento`.`tipo` AS `tipo`,`documento`.`fechaVencimiento` AS `fechavencimiento`,`documento`.`estado` AS `estado` from (`vehiculo` join `documento`) where (`vehiculo`.`vehiculoId` = `documento`.`vehiculoId`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v3`
--

/*!50001 DROP VIEW IF EXISTS `v3`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v3` AS select `flotilla`.`flotillaId` AS `flotillaId`,`flotilla`.`nombreEmpresa` AS `nombreEmpresa`,`vehiculo`.`vehiculoId` AS `vehiculoId`,`vehiculo`.`tipo` AS `tipo`,`vehiculo`.`modelo` AS `modelo` from (`flotilla` join `vehiculo`) where (`flotilla`.`flotillaId` = `vehiculo`.`flotillaId`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v1`
--

/*!50001 DROP VIEW IF EXISTS `v1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v1` AS select `conductor`.`conductorId` AS `conductorId`,`conductor`.`nombre` AS `nombre`,`ruta`.`estado` AS `estado` from (`conductor` join `ruta`) where (`conductor`.`conductorId` = `ruta`.`conductorId`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-14  1:18:46
